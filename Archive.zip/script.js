//Validate form inputs before submiting data

function validationForm(){
    var name=document.getElementById("name").value;
    var id=document.getElementById("id").value;
    var email=document.getElementById("email").value;
    var contact=document.getElementById("number").value;
    var pattern=contact.replace(/\D/g,'');
   

    if(name==""){
        alert("Name is required");
        return false;
    }

    if(id==""){
        alert("ID is required");
        return false;
    }

    if(email==""){
        alert("Email is requried");
        return false;
    }
    else if(!email.includes("@")){
        alert("Invaild email address");
        return false;
    }
   if(pattern.length!=10){
        alert("Please enter 10-digit number");
        return false;
   }
    
    
    return true;
}

function gfg_check_duplicates() {
    let myarray = [];
    for (i = 0; i < 4; i++) {
        myarray[i] =
            document.getElementsByClassName(".form-control" + i).value;
    }
    for (i = 0; i < 4; i++) {
        for (j = i + 1; j < 4; j++) {
            if (i == j || myarray[i] == "" || myarray[j] == "")
                continue;
            if (myarray[i] == myarray[j]) {
                document.getElementsByClassName(".form-control" + i)
                    .innerHTML = "duplicated values!";
                document.getElementsByClassName(".form-control" + j)
                    .innerHTML = "duplicated values!";
            }
        }
    }
}


//function to show data from local storage

function showData(){
    var peopleList;
    if(localStorage.getItem("peopleList")==null){
        peopleList=[];
    }
    else{
        peopleList=JSON.parse(localStorage.getItem("peopleList"));
    }
    var html="";

    peopleList.forEach(function(element,index){
        html+="<tr>"
        html+="<td>" + element.name + "</td>";
        html+="<td>" + element.id + "</td>";
        html+="<td>" + element.email + "</td>";
        html+="<td>" + element.number + "</td>";
        html += 
            '<td><button onclick="deleteData(' + index +')" class="btn btn-danger">Delete</button> <button onclick="updateData(' + index +')"class="btn btn-danger">Edit</button>';
        html +="</tr>";
    });
    document.querySelector("#crudTable tbody").innerHTML=html;
}

//Loads All data when document or page loaded

document.onload=showData();

//function to Add data to Local storage

function AddData(){
    //if form is validate
    if(validationForm()==true){
        var name=document.getElementById("name").value;
        var id=document.getElementById("id").value;
        var email=document.getElementById("email").value;
        var number=document.getElementById("number").value;

        var peopleList;
    if(localStorage.getItem("peopleList")==null){
        peopleList=[];
    }
    else{
        peopleList=JSON.parse(localStorage.getItem("peopleList"));
    }

    peopleList.push({
        name:name,
        id:id,
        email:email,
        number:number
    });
    localStorage.setItem("peopleList",JSON.stringify(peopleList));
    showData();
    document.getElementById("name").value="";
    document.getElementById("id").value="";
    document.getElementById("email").value="";
    document.getElementById("number").value="";
    }
}

//function to delete data from local storage
function deleteData(index){
    var peopleList;
    if(localStorage.getItem("peopleList")==null){
        peopleList=[];
    }
    else{
        peopleList=JSON.parse(localStorage.getItem("peopleList"));
    }
    peopleList.splice(index,1);
    localStorage.setItem("peopleList",JSON.stringify(peopleList));
    showData();
}
//function to update/edit data in local storage
function updateData(index){
    //submit button will hide and update button will show for updating of data in local storage
    document.getElementById("submit").style.display="none";
    document.getElementById("update").style.display="block";

    var peopleList;
    if(localStorage.getItem("peopleList")==null){
        peopleList=[];
    }
    else{
        peopleList=JSON.parse(localStorage.getItem("peopleList"));
    }

    document.getElementById("name").value=peopleList[index].name;
    document.getElementById("id").value=peopleList[index].id;
    document.getElementById("email").value=peopleList[index].email;
    document.getElementById("number").value=peopleList[index].number;

    document.querySelector("#update").onclick=function(){
        if(validationForm()==true){
            peopleList[index].name=document.getElementById("name").value;
            peopleList[index].id=document.getElementById("id").value;
            peopleList[index].email=document.getElementById("email").value;
            peopleList[index].number=document.getElementById("number").value;

            localStorage.setItem("peopleList",JSON.stringify(peopleList));

            showData();

            document.getElementById("name").value="";
            document.getElementById("id").value="";
            document.getElementById("email").value="";
            document.getElementById("number").value="";
 
            //update button will hide and submit button will show

            document.getElementById("submit").style.display="block";
            document.getElementById("update").style.display="none";
        }
    }
}